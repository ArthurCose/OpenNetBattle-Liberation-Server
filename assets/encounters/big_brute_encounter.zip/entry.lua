local big_brute_id = "com.keristero.char.BigBrute"
local music_id = "dev.konstinople.library.music.bn5"

function package_requires_scripts()
    Engine.requires_library(music_id)
    Engine.requires_character(big_brute_id)
end

function package_init(package)
    package:declare_package_id("com.discord.Konstinople#7692.encounter.big_brute.liberation")
end

function package_build(mob, data)
    mob:stream_music(include(music_id))
    mob:enable_freedom_mission(3, false)

    if data.terrain == "advantage" then
        for i = 1, 3 do
            local tile = mob:get_field():tile_at(4, i)
            tile:set_team(Team.Red, false)
            tile:set_facing(Direction.Right)
        end
    elseif data.terrain == "surrounded" or data.terrain == "disadvantage" then
        for i = 1, 3 do
            local tile = mob:get_field():tile_at(3, i)
            tile:set_team(Team.Blue, false)
            tile:set_facing(Direction.Left)
        end
    end

    mob:create_spawner(big_brute_id, Rank.V1)
       :spawn_at(5, 2)
       :mutate(function(character)
            if data.health then
                character:set_health(data.health)
            end
        end)
end
