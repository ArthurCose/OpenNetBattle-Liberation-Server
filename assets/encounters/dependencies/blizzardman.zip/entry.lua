function package_requires_scripts()
  Engine.define_character("com.discord.Konstinople#7692.enemy.blizzardman", _modpath.."character")
end

function package_init(package)
  package:declare_package_id("com.discord.Konstinople#7692.blizzardman")
  package:set_name("BlizzardMan.EXE")
  package:set_description("\"I'll freeze you to the bone!\"")
  package:set_speed(1)
  package:set_attack(20)
  package:set_health(400)
  package:set_preview_texture_path(_modpath.."preview"..math.random(2)..".png")
end

function package_build(mob)
  mob:create_spawner("com.discord.Konstinople#7692.enemy.blizzardman", Rank.V1)
    :spawn_at(5, 2)
end
