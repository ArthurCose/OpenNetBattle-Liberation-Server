function package_requires_scripts()
    Engine.define_library("dev.konstinople.library.inject_invincibility", _folderpath)
end

function package_init(package)
    package:declare_package_id("dev.konstinople.library.music.inject_invincibility.entry")
end

local function spawn_guard_hit_artifact(character)
    local artifact = Battle.Artifact.new()
    artifact:set_texture(Engine.load_texture(_folderpath.."guard_hit.png"))
    artifact:sprite():set_layer(-1)

    local artifact_anim = artifact:get_animation()
    artifact_anim:load(_folderpath.."guard_hit.animation")
    artifact_anim:set_state("DEFAULT")
    artifact_anim:refresh(artifact:sprite())

    artifact_anim:on_complete(function()
        artifact:erase()
    end)

    artifact:set_offset(
        math.floor((math.random() - .5) * character:sprite():get_width()),
        -math.random(math.floor(character:get_height())) * 2
    )

    character:get_field():spawn(artifact, character:get_tile())
end

local function give_invincibility(character)
    local defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)

    defense_rule.filter_statuses_func = function(props)
        props.damage = 0
        props.flags = 0
        return props
    end

    local tink_sfx = Engine.load_audio(_folderpath.."tink.ogg")

    defense_rule.can_block_func = function(judge, spell)
      judge:block_impact()

      if spell:copy_hit_props().damage > 0 then
        Engine.play_audio(tink_sfx, AudioPriority.Highest)
        spawn_guard_hit_artifact(character)
        judge:block_damage()
      end
    end

    character:add_defense_rule(defense_rule)

    local component = Battle.Component.new(character, Lifetimes.Local)
    local elapsed_frames = 0

    component.update_func = function()
        if defense_rule:is_replaced() then
            component:eject()
            return
        end

        if elapsed_frames >= 10 * 60 then
            character:remove_defense_rule(defense_rule)
            component:eject()
            return
        end

        elapsed_frames = elapsed_frames + 1

        local alpha = math.abs(math.sin(elapsed_frames / 60 * 5.2))
        local color = Color.new(
            0,
            math.floor(150 * alpha),
            0,
            255
        )

        character:sprite():set_color(color)
    end

    character:register_component(component)
end

local function inject_invincibility(mob)
    local field = mob:get_field()

    local entity = Battle.Artifact.new()

    entity.battle_start_func = function()
        field:find_characters(function(character)
            if Battle.Player.from(character) then
                give_invincibility(character)
            end

            return false
        end)

        entity:erase()
    end

    field:spawn(entity, 0, 0)
end

return inject_invincibility
