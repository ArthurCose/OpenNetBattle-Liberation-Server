local cactikil_id = "com.discord.Konstinople#7692.enemy.cactikil"
local cactroll_id = "com.discord.Konstinople#7692.enemy.cactroll"
local cacter_id = "com.discord.Konstinople#7692.enemy.cacter"

function package_requires_scripts()
  Engine.define_character(cactikil_id, _modpath.."cactikil")
  Engine.define_character(cactroll_id, _modpath.."cactroll")
  Engine.define_character(cacter_id, _modpath.."cacter")
end

function package_init(package)
  package:declare_package_id("com.discord.Konstinople#7692.cactikil")
  package:set_name("Cactikil")
  package:set_description(
    "Cactikil, known as \"Sabotekoron\" in Japan, is a cactus")
  -- package:set_speed(999)
  -- package:set_attack(999)
  -- package:set_health(9999)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
  mob
    :create_spawner(cactikil_id, Rank.V1)
    :spawn_at(5, 2)
  mob
    :create_spawner(cactikil_id, Rank.EX)
    :spawn_at(6, 2)

  mob
    :create_spawner(cactroll_id, Rank.V1)
    :spawn_at(5, 1)
  mob
    :create_spawner(cactroll_id, Rank.EX)
    :spawn_at(6, 1)

  mob
    :create_spawner(cacter_id, Rank.V1)
    :spawn_at(5, 3)
  mob
    :create_spawner(cacter_id, Rank.EX)
    :spawn_at(6, 3)

  mob:get_field():tile_at(3, 2):set_state(TileState.Broken)
end
