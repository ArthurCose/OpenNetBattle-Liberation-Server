function package_requires_scripts()
    Engine.define_library("dev.konstinople.library.music.bn5", _modpath.."music")
end

function package_init(package)
    package:declare_package_id("dev.konstinople.library.music.bn5.entry")
end
