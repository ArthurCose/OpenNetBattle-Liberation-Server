local powie_id = "com.discord.Konstinople#7692.enemy.powie" -- v1, EX
local data_id = "com.keristero.char.Mettaur" -- todo
local mettaur_id = "com.keristero.char.Mettaur" -- v1
local canguard_id = "com.discord.Konstinople#7692.enemy.canodumb" -- v1, v1, v3, SP

function package_requires_scripts()
    Engine.requires_character(powie_id)
    Engine.requires_character(mettaur_id)
    Engine.requires_character(canguard_id)
end

function package_init(package) 
    package:declare_package_id("com.discord.Konstinople#7692.encounter.acdc3.liberations")
end

function package_build(mob, data)
    local choice = math.random(8)
    if choice == 1 then
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(4, 1)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 2)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(4, 3)
    elseif choice == 2 then
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(6, 2)
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(4, 3)
    elseif choice == 3 then
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(6, 1)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(4, 3)
    elseif choice == 4 then
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(6, 2)
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(5, 3)
    elseif choice == 5 then
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(powie_id, Rank.V1):spawn_at(6, 3)
    elseif choice == 6 then
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(6, 1)
        mob:create_spawner(data_id, Rank.V1):spawn_at(5, 2)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(4, 3)
    elseif choice == 7 then
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(6, 2)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 3)
    elseif choice == 8 then
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(powie_id, Rank.V1):spawn_at(6, 2)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(4, 3)
    elseif choice == 9 then
        mob:create_spawner(powie_id, Rank.V1):spawn_at(6, 1)
        mob:create_spawner(powie_id, Rank.V1):spawn_at(5, 3)
    elseif choice == 10 then
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(6, 1)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(4, 3)
    elseif choice == 11 then
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(6, 2)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 3)
    elseif choice == 12 then
        mob:create_spawner(data_id, Rank.V1):spawn_at(4, 1)
        mob:create_spawner(canguard_id, Rank.V1):spawn_at(6, 2)
        mob:create_spawner(mettaur_id, Rank.V1):spawn_at(5, 3)
    end
end
